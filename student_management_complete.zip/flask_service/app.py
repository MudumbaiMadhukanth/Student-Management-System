from flask import Flask, jsonify, request

app = Flask(__name__)

@app.route("/analytics", methods=["POST"])
def analytics():
    students = request.json
    course_count = {}
    for s in students:
        course = s["course"]
        course_count[course] = course_count.get(course, 0) + 1
    return jsonify(course_count)

if __name__ == "__main__":
    app.run(port=5000)