from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List

app = FastAPI()
students_db = []

class Student(BaseModel):
    id: int
    name: str
    email: str
    course: str

@app.get("/students/", response_model=List[Student])
def get_students():
    return students_db

@app.post("/students/", response_model=Student)
def create_student(student: Student):
    for s in students_db:
        if s.id == student.id:
            raise HTTPException(status_code=400, detail="Student ID already exists")
    students_db.append(student)
    return student

@app.get("/students/{student_id}", response_model=Student)
def get_student(student_id: int):
    for s in students_db:
        if s.id == student_id:
            return s
    raise HTTPException(status_code=404, detail="Student not found")