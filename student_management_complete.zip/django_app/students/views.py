from django.shortcuts import render, redirect
import requests

FASTAPI_URL = "http://127.0.0.1:8000/students/"
FLASK_URL = "http://127.0.0.1:5000/analytics"

def home(request):
    students = requests.get(FASTAPI_URL).json()
    return render(request, "students/home.html", {"students": students})

def add_student(request):
    if request.method == "POST":
        student = {
            "id": int(request.POST["id"]),
            "name": request.POST["name"],
            "email": request.POST["email"],
            "course": request.POST["course"]
        }
        requests.post(FASTAPI_URL, json=student)
        return redirect("home")
    return render(request, "students/add_student.html")

def analytics(request):
    students = requests.get(FASTAPI_URL).json()
    result = requests.post(FLASK_URL, json=students).json()
    return render(request, "students/analytics.html", {"result": result})